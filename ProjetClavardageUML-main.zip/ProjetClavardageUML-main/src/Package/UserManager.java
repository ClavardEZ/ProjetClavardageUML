package Package;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("40154638-b4be-49f6-b07b-0d956aab30f3")
public class UserManager {
    @objid ("cba71e0a-0e72-41b7-aed9-fcc00936ddaa")
    public PrivateUser privateUser;

    @objid ("2e55a1d7-fa91-4e10-a4d3-ca6225e3d584")
    public void setUserConnected() {
    }

    @objid ("5ffa5ee3-74d6-4227-8b8e-59335dc7d6bd")
    public void selfConnected() {
    }

    @objid ("4ef50e48-916a-456c-89ee-769b60f9a8c5")
    public void isConnected() {
    }

    @objid ("f45d3ae8-0e84-4e19-9412-39d5da7e046d")
    public void notifyConnected() {
    }

}

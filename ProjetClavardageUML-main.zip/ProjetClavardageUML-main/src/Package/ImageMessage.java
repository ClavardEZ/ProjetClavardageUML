package Package;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1f4981cb-3fa6-4042-a42b-2281d400f1fd")
public class ImageMessage extends Message {
    @objid ("8a989211-21f7-4c4c-8539-57c91e059bd0")
    public String file;

}

package Model;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6dd08fa2-dc4a-4502-be52-52031e8bf5ae")
public class TextMessage extends Message {
    @objid ("557e64bd-43d3-4cd9-9cc0-e006eaadf65c")
    public String image;

}

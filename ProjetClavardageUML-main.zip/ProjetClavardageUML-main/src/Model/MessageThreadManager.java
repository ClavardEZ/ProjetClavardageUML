package Model;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6ec48c2f-c40e-4a84-9d7e-51895957439b")
public class MessageThreadManager {
    @objid ("d3642d42-c776-42e8-bc10-f7b50a8738d6")
    public void OpenConnection() {
    }

    @objid ("dbb15ef9-0bf1-4e11-8558-2b0a6539ec2c")
    public void Send(Message msg) {
    }

    @objid ("0e7865bd-de9f-492f-97d1-2b74b7c9221f")
    public MessageThreadManager() {
    }

}

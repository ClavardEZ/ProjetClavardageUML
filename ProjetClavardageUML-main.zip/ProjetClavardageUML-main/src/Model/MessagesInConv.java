package Model;

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("499bd900-c771-4875-9f5e-1ab7f46b71f3")
public class MessagesInConv {
    @objid ("04bea255-ff95-4ef8-ac5a-51e81ece287e")
    public List<Message> message = new ArrayList<Message> ();

    @objid ("f83f45a0-6a96-4a75-a5c8-0842fc5625c2")
    public MessagesInConv() {
    }

}
